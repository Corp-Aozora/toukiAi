"use strict";

const sidebar = document.getElementById("sidebar");
const btnInquiry = document.getElementById("btnInquiry");

//ロード時
window.addEventListener("load", ()=>{
})

//お問い合わせボタンが押されたとき
btnInquiry.addEventListener("click", ()=>{
    //データベースに登録する
})