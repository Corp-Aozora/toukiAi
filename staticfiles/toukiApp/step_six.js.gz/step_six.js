"use strict";

/**
 * 初期処理
 */
function initialize(){
    //サイドバーを更新
    updateSideBar();
}

/*
    イベント
*/
window.addEventListener("load", ()=>{
    initialize();
})